<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Cookies Test</title>
</head>
<body>
	<h1>This is the cookies test page</h1>
	<a href="cookies_set.php">Set Cookies</a>
	<a href="cookies_view.php">View Cookies</a>
	<a href="cookies_delete.php">Delete Cookies</a>
</body>
</html>